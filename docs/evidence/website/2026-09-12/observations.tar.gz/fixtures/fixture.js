const data = await (await fetch('./fixtures.json')).json();
const select = document.querySelector('#fixture');
for (const fixture of data.fixtures) { const option = document.createElement('option'); option.value = fixture.id; option.textContent = fixture.title; select.append(option); }
const selected = () => data.fixtures.find(f => f.id === select.value);
let emissions = 0;
let previous;
function preview() { const f = selected(); document.querySelector('#metadata').textContent = JSON.stringify({ ...data.metadata, selected: f.id, options: f.options, userAgent: navigator.userAgent, viewport: [innerWidth,innerHeight] }, null, 2); document.querySelector('#preview').textContent = 'No page image is loaded during native Console qualification.'; }
function emit(args, id) { console.log(...args); previous=args; emissions++; document.querySelector('#status').textContent = emissions + ' explicit emission(s). Last: ' + id; }
document.querySelector('#emit').onclick=()=>{const f=selected();emit(f.output.args,f.id);};
document.querySelector('#repeat').onclick=()=>{if(previous)emit(previous,'identical arguments');};
document.querySelector('#static').onclick=()=>{const f=selected();emit(f.staticOutput.args,f.id+' static');};
select.onchange=preview; preview();
window.consoleFxFixtures = data;
