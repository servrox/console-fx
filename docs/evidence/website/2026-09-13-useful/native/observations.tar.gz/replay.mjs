import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const [sourceCommit] = process.argv.slice(2);
assert(/^[a-f0-9]{40}$/.test(sourceCommit));
const fromRoot = path => import(pathToFileURL(resolve(path)));
const {EXAMPLES,exampleRecipe}=await fromRoot('apps/studio/src/features/landing/examples.ts');
const {compileConsole}=await fromRoot('packages/console-fx/dist/browser/index.js');
const {exportConsoleLog}=await fromRoot('packages/console-fx/dist/codegen/index.js');
const sha = value => createHash('sha256').update(value).digest('hex');
const bytes = await readFile('.artifacts/review/useful-native/chrome-02/fixtures.json');
const fixtures = JSON.parse(bytes);
assert.deepEqual(fixtures.map(f=>f.id),EXAMPLES.filter(e=>e.category==='useful').map(e=>e.id));
for(const fixture of fixtures) {
 const recipe=exampleRecipe(fixture.id);
 assert.deepEqual(recipe,fixture.recipe);
 assert.deepEqual(compileConsole(recipe.scene,recipe.options),fixture.output);
 assert.equal(exportConsoleLog(recipe.scene,recipe.options).code,fixture.code);
 assert.equal(sha(fixture.code),fixture.codeSha256);
}
const receipt={stage:'source/static',status:'verified',observedAt:new Date().toISOString(),obligation:'Retained native fixtures exactly match freshly rebuilt source',sourceCommit,fixturesSha256:sha(bytes),cases:fixtures.map(f=>f.id),command:'pnpm run build:packages; node .artifacts/review/useful-native/replay.mjs <verified-git-HEAD>',harnessSha256:sha(await readFile(new URL(import.meta.url))),node:process.version,limits:['Deterministic source replay; no new browser or hosted observation']};
await writeFile('.artifacts/review/useful-native/source-replay.json',JSON.stringify(receipt,null,2)+'\n');
console.log('All three native fixtures match freshly rebuilt source exactly');
