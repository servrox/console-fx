import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync,writeFileSync} from 'node:fs';
import * as oldCore from './baseline-core/package/dist/browser/index.js';
import * as oldCode from './baseline-core/package/dist/codegen/index.js';
import * as current from '../../packages/console-fx/dist/browser/index.js';
import * as code from '../../packages/console-fx/dist/codegen/index.js';
import {PRESETS,createPresetExample} from '../../packages/console-fx/dist/presets/index.js';
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const fixtures = ['fitting','website'].flatMap(name=>JSON.parse(readFileSync(`.artifacts/${name}/native-cases.json`,'utf8')));
for(const preset of PRESETS) for(const renderer of ['css','svg','text']) for(const motion of ['reduce','allow']) fixtures.push({id:`legacy-${preset.id}-${renderer}-${motion}`,scene:createPresetExample(preset.id),options:{target:'chromium',renderer,motion,unsupported:'fallback'}});
const rows=[];
function capture(fn){try{return {ok:true,value:fn()};}catch(error){if(!error.diagnostics)throw error;return {ok:false,diagnostics:error.diagnostics};}}
for(const entry of fixtures){
 const options={target:'chromium',renderer:entry.renderer,motion:entry.motion??'reduce',...entry.options};
 const exportOptions={...options,motion:options.motion==='allow'?'system':'reduce'};
 const before=capture(()=>oldCore.compileConsole(entry.scene,options));
 const after=capture(()=>current.compileConsole(entry.scene,options));
 assert.deepEqual(after,before,`${entry.id}: output`);
 const oldExport=capture(()=>oldCode.exportConsoleLog(entry.scene,exportOptions));
 const newExport=capture(()=>code.exportConsoleLog(entry.scene,exportOptions));
 assert.deepEqual(newExport,oldExport,`${entry.id}: export`);
 let preflight;
 if(options.layout){
  const preflightOptions={...options,measurementEnvironment:options.measurementEnvironment??'comparison/v1'};
  const first=oldCore.prepareTextMeasurements(entry.scene,preflightOptions);
  const second=current.prepareTextMeasurements(entry.scene,preflightOptions);
  assert.deepEqual(second,first,`${entry.id}: preflight`);
  preflight=hash(JSON.stringify(second));
 }
 rows.push({id:entry.id,compiled:after.ok,outputSha256:hash(JSON.stringify(after)),exportSha256:hash(JSON.stringify(newExport)),...(preflight?{preflightSha256:preflight}:{})});
}
const receipt={at:new Date().toISOString(),baselineCommit:'3316574868716ac673e1e3ba73e9da272aaa9c30',baselineCoreSha256:hash(readFileSync('.artifacts/review/main-ci/34712881764/extracted/.artifacts/packages/servrox-console-fx-0.1.0.tgz')),currentCoreSha256:hash(readFileSync('.artifacts/packages/servrox-console-fx-0.1.0.tgz')),fixtures:rows.length,comparisons:rows.length*2+rows.filter(r=>r.preflightSha256).length,rows};
writeFileSync('.artifacts/improvements/output-identity.json',JSON.stringify(receipt,null,2)+'\n');
console.log(`${receipt.comparisons} identical output/export/preflight comparisons across ${receipt.fixtures} fixtures`);
