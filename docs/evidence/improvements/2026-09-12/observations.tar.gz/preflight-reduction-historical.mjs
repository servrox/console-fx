// Historical in-memory experiment, observed 2026-09-12 before source extraction.
// Run from the integration worktree only after restoring the exact recorded
// inputs AND their matching built dist in an isolated environment. Does not write source.

import {readFileSync} from "node:fs";import {build} from "esbuild";import ts from "typescript";import assert from "node:assert/strict";import {createHash} from "node:crypto";import {gzipSync,gunzipSync} from "node:zlib";
const metrics=readFileSync("packages/console-fx/src/layout/metrics.ts","utf8"),planner=readFileSync("packages/console-fx/src/layout/planner.ts","utf8"),preflight=readFileSync("packages/console-fx/src/browser/preflight.ts","utf8");

// Guard added when saving the historical experiment. Applied source must not be
// transformed again or misreported as a fresh pass. See the companion receipt.
const expectedInputs = {
  "layout/metrics.ts": "e36f4cdd2fde289173b4d19aa413b1341d16badef4687ddea6a95607cadc8e24",
  "layout/planner.ts": "dabac1ea517a496d13aecc6a2e1770f0b48bdf9b1ebd7b48ead6d39814344128",
  "browser/preflight.ts": "d80ad5bce95e008fdd1835f2caeec2df7b7c02791092cdbfacf88289890ee259"
};
for (const [file, source] of [["layout/metrics.ts", metrics], ["layout/planner.ts", planner], ["browser/preflight.ts", preflight]]) {
  assert.equal(createHash("sha256").update(source).digest("hex"), expectedInputs[file], "Historical pre-extraction input required: " + file);
}
const alternatives=metrics.slice(metrics.indexOf("  private readonly alternatives:"),metrics.indexOf("  constructor("));
const start=metrics.indexOf("  suggest("),end=metrics.indexOf("  private request("),methods=metrics.slice(start,end);
const nextMetrics=metrics.replace(alternatives, '  declare readonly suggest?: (alternatives: Iterable<TextRun>, profile?: string) => void;\n').replace(methods,"").replace("  private bytes:", "  protected bytes:").replace("  private request(", "  protected request(");
const nextPlanner=planner.replaceAll("resolver.suggest(", "resolver.suggest?.(");
const nextPreflight=preflight.replace('import { deepFreeze }','import { deepFreeze, LIMITS, utf8ByteLength }').replace('  CompileOptions,','  TextRun,\n  CompileOptions,').replace('new MetricResolver(', 'new PreflightMetricResolver(')
.replace('/** Pure preflight.', 'class PreflightMetricResolver extends MetricResolver {\n'+alternatives+methods.replace('  suggest(alternatives: Iterable<TextRun>, profile = "flow/v1"): void {','  override readonly suggest = (alternatives: Iterable<TextRun>, profile = "flow/v1"): void => {').replace('  }\n  /** Fill spare','  };\n  /** Fill spare')+'}\n\n/** Pure preflight.');
const candidate={metrics:nextMetrics,planner:nextPlanner,preflight:nextPreflight};const outputs=Object.fromEntries(Object.entries(candidate).map(([k,v])=>[k,ts.transpileModule(v,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText]));
const plugin={name:"candidate",setup(b){b.onLoad({filter:/\/(?:layout\/(?:metrics|planner)|browser\/preflight)\.js$/},a=>{const name=a.path.split("/").at(-1).slice(0,-3);return{contents:outputs[name],loader:"js"};});}};
for(const [fixture,renderer,effect,compiler]of[["css","css","neon","compileCssConsole"],["complete-css","css","neon","compileConsole"],["svg","svg","rainbow","compileConsole"]]){
const contents=`import { defineScene } from "@servrox/console-fx";\nimport { ${compiler} } from "@servrox/console-fx/browser";\nexport const message = ${compiler}(defineScene({schemaVersion:1,label:"Bundle fixture",lines:[{runs:[{text:"Bundle fixture",effects:[{kind:"${effect}"}]}]}]}), {${compiler==="compileConsole"?`renderer:"${renderer}",`:""}target:"chromium"});\n`;
const b=await build({stdin:{contents,resolveDir:process.cwd()+"/apps/studio",sourcefile:fixture+".mjs"},bundle:true,write:false,minify:true,format:"esm",platform:"browser",target:"es2022",plugins:[plugin]});
console.log(JSON.stringify({fixture,gzip:gzipSync(b.outputFiles[0].contents,{level:9}).length,raw:b.outputFiles[0].contents.length}));
}

const bundleApi=async useCandidate=>{
 const result=await build({stdin:{contents:'export {compileConsole,prepareTextMeasurements} from "@servrox/console-fx/browser";export {exportConsoleLog} from "@servrox/console-fx/codegen";',resolveDir:process.cwd()+"/apps/studio"},bundle:true,write:false,format:"esm",platform:"node",target:"es2022",plugins:useCandidate?[plugin]:[]});
 return import("data:text/javascript;base64,"+Buffer.from(result.outputFiles[0].text).toString("base64"));
};
const [before,after]=await Promise.all([bundleApi(false),bundleApi(true)]);
const tar=gunzipSync(readFileSync("docs/evidence/fitting/2026-09-12/observations.tar.gz"));let fixtureDocument;
for(let i=0;i+512<=tar.length;){const h=tar.subarray(i,i+512),name=h.subarray(0,100).toString().replace(/\0.*$/s,""),size=parseInt(h.subarray(124,136).toString(),8)||0;if(name==="fixtures/fixtures.json")fixtureDocument=JSON.parse(tar.subarray(i+512,i+512+size).toString());i+=512+Math.ceil(size/512)*512;}
const fixtures=Array.isArray(fixtureDocument)?fixtureDocument:fixtureDocument.fixtures;
assert(Array.isArray(fixtures));
const capture=(fn,...args)=>{try{return JSON.stringify({ok:true,value:fn(...args)});}catch(error){return JSON.stringify({ok:false,name:error.name,diagnostics:error.diagnostics,message:error.message});}};
let comparisons=0;
for(const fixture of fixtures){
 const frozen=JSON.stringify(fixture.scene);
 for(const fn of ["compileConsole","exportConsoleLog"]){assert.equal(capture(after[fn],fixture.scene,fixture.options),capture(before[fn],fixture.scene,fixture.options),fixture.id+" "+fn);comparisons++;}
 const options={...fixture.options,renderer:"svg",motion:fixture.options.motion??"reduce",layout:fixture.options.layout??{algorithm:"fit/v1",width:360,maxHeight:400,variant:"standard",overflow:"wrap-then-shrink",minFontSize:8},measurementEnvironment:"review/v1"};
 assert.equal(capture(after.prepareTextMeasurements,fixture.scene,options),capture(before.prepareTextMeasurements,fixture.scene,options),fixture.id+" preflight");comparisons++;
 assert.equal(JSON.stringify(fixture.scene),frozen);
}
const originalSegmenter=Intl.Segmenter;
try{
 for(const segmented of [true,false]){
  Intl.Segmenter=segmented?originalSegmenter:undefined;
  for(const text of ["", "alpha beta gamma", "a \u2060b", "a \ufeffb", "中文日本語", "a\u0308 👩‍💻🇩🇪", "unbreakableabcdefghijklmnop"]){
   const scene={schemaVersion:1,label:"edge",surface:{width:200,height:200,padding:0},lines:[{runs:[{text,style:{fontSize:12}}]}]};
   for(const overflow of ["error","wrap","shrink","wrap-then-shrink"]){
    for(const width of [30,60,160]){
     const options={renderer:"svg",motion:"reduce",layout:{algorithm:"fit/v1",width,maxHeight:200,variant:"standard",overflow,minFontSize:8},measurementEnvironment:"review/v1"};
     for(const fn of ["compileConsole","prepareTextMeasurements"]){assert.equal(capture(after[fn],scene,options),capture(before[fn],scene,options),JSON.stringify({segmented,text,overflow,width,fn}));comparisons++;}
    }
   }
  }
 }
}finally{Intl.Segmenter=originalSegmenter;}
console.log(JSON.stringify({equalComparisons:comparisons,fixtureCount:fixtures.length,covered:"compile, generated exports, preflight, empty/Unicode/joiner/CJK, all overflow policies, absent Segmenter",sourceUnchanged:true}));
const configPath=ts.findConfigFile("packages/console-fx",ts.sys.fileExists,"tsconfig.json");
const parsed=ts.getParsedCommandLineOfConfigFile(configPath,{noEmit:true},{...ts.sys,onUnRecoverableConfigFileDiagnostic:d=>{throw new Error(ts.flattenDiagnosticMessageText(d.messageText,"\n"))}});
const sourceMap=new Map(Object.entries(candidate).map(([key,value])=>[ts.sys.resolvePath(key==="preflight"?"packages/console-fx/src/browser/preflight.ts":"packages/console-fx/src/layout/"+key+".ts"),value]));
const host=ts.createCompilerHost(parsed.options);const originalGet=host.getSourceFile;
host.getSourceFile=(name,languageVersion,...rest)=>sourceMap.has(ts.sys.resolvePath(name))?ts.createSourceFile(name,sourceMap.get(ts.sys.resolvePath(name)),languageVersion,true):originalGet.call(host,name,languageVersion,...rest);
const diagnostics=ts.getPreEmitDiagnostics(ts.createProgram(parsed.fileNames,parsed.options,host));
console.log(JSON.stringify({typeDiagnostics:diagnostics.map(d=>ts.flattenDiagnosticMessageText(d.messageText,"\n"))}));
assert.equal(diagnostics.length,0);
console.log(JSON.stringify({sourceHashes:Object.fromEntries([["layout/metrics.ts",metrics],["layout/planner.ts",planner],["browser/preflight.ts",preflight]].map(([file,source])=>[file,createHash("sha256").update(source).digest("hex")]))}));

