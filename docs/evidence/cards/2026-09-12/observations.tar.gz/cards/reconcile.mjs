import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,readdirSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createPresetExample,PRESETS} from '../../packages/console-fx/dist/presets/index.js';
import {compileConsole} from '../../packages/console-fx/dist/browser/index.js';
import {exportConsoleLog} from '../../packages/console-fx/dist/codegen/index.js';
import {parseScene as parseOld} from '../../../console-fx-cinematic/packages/console-fx/dist/index.js';
const dest='docs/evidence/cards/2026-09-12';mkdirSync(dest,{recursive:true});
const hash=x=>createHash('sha256').update(x).digest('hex');
const candidate=JSON.parse(readFileSync('.artifacts/packages/candidate.json'));
const oldCore='../console-fx-cinematic/.artifacts/packages/servrox-console-fx-0.1.0.tgz';
const oldSha=hash(readFileSync(oldCore));assert.equal(oldSha,'1d1bfbcce41cc4880d582db9cb4e4f6590ed87f806bfe43cbd5ca369bd994649');
const oldRows=PRESETS.filter(p=>p.group==='Useful'||p.group==='Artful').map(p=>{const result=parseOld(createPresetExample(p.id));assert(!result.ok);assert(result.diagnostics.some(d=>d.code==='unknown-property'));return {id:p.id,result};});
writeFileSync(`${dest}/older-reader.json`,JSON.stringify({observedAt:new Date().toISOString(),oldCoreSha256:oldSha,rows:oldRows},null,2)+'\n');
const observations=[];
for(const dir of readdirSync('.artifacts/devtools').filter(n=>n.includes('-lifecycle-')&&existsSync(`.artifacts/devtools/${n}/observations.json`))){
 const report=JSON.parse(readFileSync(`.artifacts/devtools/${dir}/observations.json`));
 for(const c of report.cases){
  const id=c.id.split('-')[0],scene=createPresetExample(id),opts={target:'chromium',renderer:'svg'};
  const compiled=compileConsole(scene,opts);assert.deepEqual(c.expectedArgs,compiled.args);assert.equal(c.expectedText,compiled.text);assert(c.argumentsEqual);assert.equal(c.consoleCalls,1);
  if(c.code)assert.equal(c.code,exportConsoleLog(scene,opts).code);
  assert(c.visibleText.includes(compiled.text));
  if(c.copiedText)assert(c.copiedText.replaceAll('\r\n','\n').includes(compiled.text));
  observations.push({directory:dir,id:c.id,argsSha256:hash(JSON.stringify(compiled.args)),codeSha256:c.code?hash(c.code):null,captureMethod:c.captureMethod??'Playwright screenshot; original 200% display contexts are partial and replaced'});
 }
}
assert.equal(observations.length,200);
writeFileSync(`${dest}/output-identity.json`,JSON.stringify({observedAt:new Date().toISOString(),candidate: candidate.packages.map(({name,sha256})=>({name,sha256})),checks:'Every observed argument array, complete caption and generated source equals the final compiler. Exactly one call in each row. Windows clipboard CRLF alone normalized for semantic comparison.',rows:observations},null,2)+'\n');
console.log({oldReaders:oldRows.length,nativeObservations:observations.length});
